from datetime import datetime

class ActivityManager:
    def __init__(self):
        self.activities = []

    def add_activity(self, employee, description):
        activity = {
            'employee': employee,
            'description': description,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.activities.append(activity)

    def get_activities(self):
        return self.activities

# Example usage
activity_manager = ActivityManager()

def log_activity(employee, description):
    activity_manager.add_activity(employee, description)

def get_all_activities():
    return activity_manager.get_activities()
