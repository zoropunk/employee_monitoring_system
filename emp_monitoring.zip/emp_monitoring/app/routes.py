from flask import Blueprint, render_template, request, redirect, url_for
from datetime import datetime
from .activity import log_activity, get_all_activities
from .forms import AddEmployeeForm, AddTaskForm, UpdateTaskForm, LogTimeForm, RatePerformanceForm

main = Blueprint('main', __name__)

# Simulated databases
employees = []
tasks = []
time_entries = []
performance_ratings = []

@main.route('/')
def home():
    activities = get_all_activities()
    add_employee_form = AddEmployeeForm()
    add_task_form = AddTaskForm()
    update_task_form = UpdateTaskForm()
    log_time_form = LogTimeForm()
    rate_performance_form = RatePerformanceForm()
    # Set choices for dynamic fields
    log_time_form.employee.choices = [(e, e) for e in employees]
    rate_performance_form.employee.choices = [(e, e) for e in employees]

    return render_template(
        'home.html',
        employees=employees,
        tasks=tasks,
        time_entries=time_entries,
        performance_ratings=performance_ratings,
        activities=activities,
        add_employee_form=add_employee_form,
        add_task_form=add_task_form,
        update_task_form=update_task_form,
        log_time_form=log_time_form,
        rate_performance_form=rate_performance_form
    )

@main.route('/add_employee', methods=['POST'])
def add_employee():
    name = request.form.get('name')
    employees.append(name)
    return redirect(url_for('main.home'))

@main.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task_name')
    tasks.append({'name': task_name, 'status': 'Pending', 'start_time': None, 'end_time': None})
    return redirect(url_for('main.home'))

@main.route('/update_task/<int:index>', methods=['POST'])
def update_task(index):
    tasks[index]['status'] = request.form.get('status')
    return redirect(url_for('main.home'))

@main.route('/start_task/<int:index>', methods=['POST'])
def start_task(index):
    tasks[index]['start_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_activity('employee_name', 'Started task: {}'.format(tasks[index]['name']))
    return redirect(url_for('main.home'))

@main.route('/end_task/<int:index>', methods=['POST'])
def end_task(index):
    tasks[index]['end_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_activity('employee_name', 'Ended task: {}'.format(tasks[index]['name']))
    return redirect(url_for('main.home'))

@main.route('/log_time', methods=['POST'])
def log_time():
    employee = request.form.get('employee')
    task_name = request.form.get('task_name')
    hours = request.form.get('hours')
    time_entries.append({'employee': employee, 'task_name': task_name, 'hours': hours, 'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
    log_activity(employee, 'Logged time for task: {}'.format(task_name))
    return redirect(url_for('main.home'))

@main.route('/rate_performance', methods=['POST'])
def rate_performance():
    employee = request.form.get('employee')
    rating = request.form.get('rating')
    performance_ratings.append({'employee': employee, 'rating': rating, 'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
    return redirect(url_for('main.home'))
