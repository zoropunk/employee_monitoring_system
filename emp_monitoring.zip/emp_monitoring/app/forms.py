from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, FloatField, DateField, SelectField, SubmitField
from wtforms.validators import DataRequired

class AddEmployeeForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    submit = SubmitField('Add Employee')

class AddTaskForm(FlaskForm):
    task_name = StringField('Task Name', validators=[DataRequired()])
    submit = SubmitField('Add Task')

class UpdateTaskForm(FlaskForm):
    status = SelectField('Status', choices=[('Pending', 'Pending'), ('Completed', 'Completed')])
    submit = SubmitField('Update Task')

class LogTimeForm(FlaskForm):
    employee = SelectField('Employee', choices=[], validators=[DataRequired()])
    task_name = StringField('Task Name', validators=[DataRequired()])
    hours = FloatField('Hours Worked', validators=[DataRequired()])
    submit = SubmitField('Log Time')

class RatePerformanceForm(FlaskForm):
    employee = SelectField('Employee', choices=[], validators=[DataRequired()])
    rating = IntegerField('Rating (1-5)', validators=[DataRequired()])
    submit = SubmitField('Rate Performance')

